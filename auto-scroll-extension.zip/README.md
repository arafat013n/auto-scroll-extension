# 🚀 Auto Scroll AI - YouTube & Facebook

**Auto Scroll AI** একটি শক্তিশালী এবং হালকা ওজনের ব্রাউজার এক্সটেনশন যা আপনার ভিডিও দেখার অভিজ্ঞতাকে আরও সহজ করে তোলে। এটি ইউটিউব শর্টস (YouTube Shorts) এবং ফেসবুক রিলস (Facebook Reels) শেষ হওয়ার সাথে সাথে অটোমেটিক পরবর্তী ভিডিওতে স্ক্রোল করে।

![Extension Icon](icon.png)

## ✨ বৈশিষ্ট্যসমূহ (Features)

- **অটো-স্ক্রোল:** ভিডিও শেষ হওয়া মাত্রই স্মুথলি পরবর্তী ভিডিওতে নিয়ে যায়।
- **স্মার্ট টগল:** পপআপ মেনু থেকে যেকোনো সময় সার্ভিসটি অন বা অফ করা যায়।
- **স্টেট মেমোরি:** ব্রাউজার রিস্টার্ট বা রিফ্রেশ করলেও আপনার সেটিংস (On/Off) মনে রাখে।
- **মাল্টি-প্ল্যাটফর্ম:** YouTube Shorts এবং Facebook Reels/Watch-এ সমানভাবে কার্যকর।
- **ডার্ক/লাইট মোড সাপোর্ট:** আধুনিক এবং ক্লিন ইউজার ইন্টারফেস।

## 🌐 সমর্থিত ব্রাউজার (Supported Browsers)

- ✅ Firefox (Tested)
- ✅ Google Chrome
- ✅ Microsoft Edge
- ✅ Brave Browser

## 🛠 ইনস্টলেশন গাইড (Installation)

### ফায়ারফক্সের জন্য (Firefox):

1. এই রিপোজিটরি থেকে জিপ ফাইলটি ডাউনলোড করে আনজিপ করুন।
2. ফায়ারফক্সের অ্যাড্রেস বারে `about:debugging#/runtime/this-firefox` লিখুন।
3. **"Load Temporary Add-on..."** বাটনে ক্লিক করুন।
4. আপনার ফোল্ডার থেকে `manifest.json` ফাইলটি সিলেক্ট করুন।

### ক্রোমের জন্য (Chrome/Edge/Brave):

1. `chrome://extensions/` লিঙ্কে যান।
2. **Developer Mode** অন করুন।
3. **"Load unpacked"** বাটনে ক্লিক করে প্রজেক্ট ফোল্ডারটি সিলেক্ট করুন।

## 👨‍💻 ডেভেলপার (Developer)

**OBAYDUL HAQUE AKASH** একজন প্যাশনেট ডেভেলপার যিনি নতুন কিছু তৈরি করতে পছন্দ করেন।

---

[<img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" />](https://www.facebook.com/akash06r)
[<img src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white" />](https://github.com/arafat013n)

## 📄 লাইসেন্স (License)

এই প্রজেক্টটি MIT লাইসেন্সের অধীনে উন্মুক্ত।

---

_মেড উইথ ❤️ ইন বাংলাদেশ_
